1 open terminal cmd in this folder
3 type pip install virtualenv
4 type virtualenv env
5 type env\Scripts\activate
6 type python manage.py runserver